//
//  RemItem.swift
//  Reminder
//
//  Created by 颜同路 on 2021/11/1.
//

import UIKit

class RemItem: NSObject, Encodable, Decodable {
    var title:String
    var isChecked: Bool
    
    init(title:String, isChecked:Bool){
        self.isChecked = isChecked
        self.title = title
    }
}
